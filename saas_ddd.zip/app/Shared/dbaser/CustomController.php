<?php

namespace Shared\dbaser;

use \Illuminate\Database\Eloquent\Model;

class CustomController extends Model
{


}




